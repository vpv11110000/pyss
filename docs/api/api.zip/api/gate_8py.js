var gate_8py =
[
    [ "Gate", "classpyss_1_1gate_1_1_gate.html", "classpyss_1_1gate_1_1_gate" ],
    [ "main", "gate_8py.html#a62e8fc55c3b51643877265492b66e501", null ]
];