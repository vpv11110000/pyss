var func__normal_8py =
[
    [ "Normal", "classpyss_1_1func__normal_1_1_normal.html", "classpyss_1_1func__normal_1_1_normal" ],
    [ "main", "func__normal_8py.html#aaa5e775f3277d9776fbabc561698b82d", null ]
];