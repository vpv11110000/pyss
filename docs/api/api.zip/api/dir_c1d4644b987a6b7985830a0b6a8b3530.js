var dir_c1d4644b987a6b7985830a0b6a8b3530 =
[
    [ "bernoulli.py", "bernoulli_8py.html", "bernoulli_8py" ],
    [ "binominal.py", "binominal_8py.html", "binominal_8py" ],
    [ "discrete_uniform_distribution.py", "discrete__uniform__distribution_8py.html", "discrete__uniform__distribution_8py" ],
    [ "hypergeometric_distribution.py", "hypergeometric__distribution_8py.html", "hypergeometric__distribution_8py" ],
    [ "poisson.py", "poisson_8py.html", "poisson_8py" ]
];