var classpyss_1_1pyssownerobject_1_1_pyss_owner_object =
[
    [ "__init__", "classpyss_1_1pyssownerobject_1_1_pyss_owner_object.html#a5f22fcfb032594299145ab9374807c99", null ],
    [ "__str__", "classpyss_1_1pyssownerobject_1_1_pyss_owner_object.html#aec15a7a9dbf4aa6f6f05414abcea6d0e", null ],
    [ "getOwner", "classpyss_1_1pyssownerobject_1_1_pyss_owner_object.html#aad29c2120a11085030875c2d4a28912e", null ],
    [ "setlabel", "classpyss_1_1pyssownerobject_1_1_pyss_owner_object.html#a9844a5b6a1dbb421b424b75478ce5ca4", null ]
];