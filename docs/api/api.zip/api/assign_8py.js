var assign_8py =
[
    [ "Assign", "classpyss_1_1assign_1_1_assign.html", "classpyss_1_1assign_1_1_assign" ],
    [ "main", "assign_8py.html#ace0e366bb518b8bc9f01a81ae6c6270b", null ]
];