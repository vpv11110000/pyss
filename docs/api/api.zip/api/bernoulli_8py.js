var bernoulli_8py =
[
    [ "main", "bernoulli_8py.html#a717afb0c4164f6e6bef1f955a8446423", null ],
    [ "DIRNAME_MODULE", "bernoulli_8py.html#a1d57721239613e43e01c51bd12b25f74", null ]
];