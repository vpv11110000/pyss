var bprint_8py =
[
    [ "Bprint", "classpyss_1_1bprint_1_1_bprint.html", "classpyss_1_1bprint_1_1_bprint" ],
    [ "main", "bprint_8py.html#ad72f39292f2260f676c9475d249ee80a", null ]
];