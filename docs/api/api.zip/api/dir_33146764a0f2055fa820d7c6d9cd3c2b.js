var dir_33146764a0f2055fa820d7c6d9cd3c2b =
[
    [ "periodic.py", "periodic_8py.html", "periodic_8py" ]
];