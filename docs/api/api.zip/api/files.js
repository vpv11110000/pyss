var files =
[
    [ "examples", "dir_d28a4824dc47e487b107a5db32ef43c4.html", "dir_d28a4824dc47e487b107a5db32ef43c4" ],
    [ "other", "dir_c1d4644b987a6b7985830a0b6a8b3530.html", "dir_c1d4644b987a6b7985830a0b6a8b3530" ],
    [ "pyss", "dir_00149498a555f6eb7ce90e5c46a97adb.html", "dir_00149498a555f6eb7ce90e5c46a97adb" ],
    [ "tests", "dir_59425e443f801f1f2fd8bbe4959a3ccf.html", "dir_59425e443f801f1f2fd8bbe4959a3ccf" ],
    [ "discover_tests.py", "discover__tests_8py.html", "discover__tests_8py" ],
    [ "setup.py", "setup_8py.html", "setup_8py" ]
];