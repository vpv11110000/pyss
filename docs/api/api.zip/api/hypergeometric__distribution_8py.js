var hypergeometric__distribution_8py =
[
    [ "main", "hypergeometric__distribution_8py.html#a4a8e34dde1c43891988d26c8a13a2bb2", null ],
    [ "DIRNAME_MODULE", "hypergeometric__distribution_8py.html#a27451157d97873a9c1136410cdf3ae3f", null ]
];