var dir_c580c89cf421cf28a7d2284e30017962 =
[
    [ "carusel.py", "carusel_8py.html", "carusel_8py" ]
];