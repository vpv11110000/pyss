var leave_8py =
[
    [ "Leave", "classpyss_1_1leave_1_1_leave.html", "classpyss_1_1leave_1_1_leave" ],
    [ "main", "leave_8py.html#afcff400036a9f043572dac37201a06d6", null ]
];