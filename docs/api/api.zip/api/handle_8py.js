var handle_8py =
[
    [ "Handle", "classpyss_1_1handle_1_1_handle.html", "classpyss_1_1handle_1_1_handle" ],
    [ "main", "handle_8py.html#a711a0998ff8cc149960e293d7edd7027", null ]
];