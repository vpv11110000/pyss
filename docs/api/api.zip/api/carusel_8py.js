var carusel_8py =
[
    [ "buildModel", "carusel_8py.html#ac0cffa9574411d97cd8d83ed6d5c487d", null ],
    [ "main", "carusel_8py.html#a5e0fdf3fe8ed696532cdcdd111161ab6", null ],
    [ "DIRNAME_MODULE", "carusel_8py.html#a2ed87f3436fa88718c487894f1f67e86", null ],
    [ "PRODUCT_COUNT", "carusel_8py.html#a3d6396173d7b2e9c40f8d21d6e40d1bf", null ]
];