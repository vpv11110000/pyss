var day__no__stacionar__one__kassa_8py =
[
    [ "main", "day__no__stacionar__one__kassa_8py.html#a21880b9b98439974edd08947d1b29316", null ],
    [ "DIRNAME_MODULE", "day__no__stacionar__one__kassa_8py.html#a0253db79146e0c5345395eb1990c9a85", null ]
];