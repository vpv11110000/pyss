var func__discrete_8py =
[
    [ "FuncDiscrete", "classpyss_1_1func__discrete_1_1_func_discrete.html", "classpyss_1_1func__discrete_1_1_func_discrete" ],
    [ "main", "func__discrete_8py.html#a9db697b167b3109fadfa951b99f60414", null ]
];