var dir_a79259edb602ac5e434926a655f660ac =
[
    [ "telephone.py", "telephone_8py.html", "telephone_8py" ]
];