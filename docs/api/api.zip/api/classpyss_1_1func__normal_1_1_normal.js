var classpyss_1_1func__normal_1_1_normal =
[
    [ "__init__", "classpyss_1_1func__normal_1_1_normal.html#a929fc92708d81d283e16249482569c04", null ],
    [ "get", "classpyss_1_1func__normal_1_1_normal.html#a04341a6eb21efcabe9e3ef24dff1e034", null ]
];