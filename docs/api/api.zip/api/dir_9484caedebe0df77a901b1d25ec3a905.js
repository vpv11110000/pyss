var dir_9484caedebe0df77a901b1d25ec3a905 =
[
    [ "qcontrol.py", "qcontrol_8py.html", "qcontrol_8py" ]
];