var binominal_8py =
[
    [ "main", "binominal_8py.html#a1109ba77c40bbeb31bcb21019abb7039", null ],
    [ "DIRNAME_MODULE", "binominal_8py.html#ae07d7d95cab7f1e03ebef9d4e9ac39dc", null ],
    [ "N", "binominal_8py.html#ae3a51ab4317af7aa06865483cd55a192", null ]
];