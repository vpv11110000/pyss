var modificatorfunc_8py =
[
    [ "main", "modificatorfunc_8py.html#a67e2b49afb03a1173b0f426573d3dc35", null ],
    [ "none", "modificatorfunc_8py.html#a6e5f5d2aead9062a599ef0e6b8211a1a", null ],
    [ "uniform", "modificatorfunc_8py.html#af2437214a38bd2e7229e379a98bc4f37", null ],
    [ "zero", "modificatorfunc_8py.html#a9d563babcd5ddf6d15d10abde729d76b", null ]
];